# Example: lista-con-filtros — fondos de inversión

## Metadata
```yaml
screen_id: SCR-001
pattern: lista-con-filtros
brief: "quiero ver mis fondos de inversión"
status: APPROVED
confidence: 0.88
approved_at: 2025-06-01
approved_by: pablo.reguera
```

## Intent
```yaml
intent_type: browse
domain: fondos
constraints:
  has_filters: true
  is_destructive: false
  requires_confirmation: false
```

## Componentes

| order | component          | variant   | required | node_id |
|-------|--------------------|-----------|----------|---------|
| 01    | navigation-header  | default   | true     | 1:3     |
| 02    | filter-bar         | default   | true     | 1:24    |
| 03    | card-item          | default   | true     | 1:13    |
| 04    | empty-state        | default   | true     | 1:31    |

## Reglas aplicadas
- empty-state excluido visualmente por presencia de card-item (exclusivity rule)
- filter-bar siempre debajo de navigation-header (positioning rule)
- max 1 navigation-header por pantalla (max-instances rule)

## Notas de aprobación
Pantalla válida para cualquier brief relacionado con listados de activos financieros con capacidad de filtrado. Cubre fondos, acciones, ETFs y productos similares.
