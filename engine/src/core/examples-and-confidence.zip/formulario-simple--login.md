# Example: formulario-simple — login

## Metadata
```yaml
screen_id: SCR-002
pattern: formulario-simple
brief: "el usuario necesita iniciar sesión en su cuenta"
status: APPROVED
confidence: 0.82
approved_at: 2025-06-01
approved_by: pablo.reguera
```

## Intent
```yaml
intent_type: authenticate
domain: login
constraints:
  has_filters: false
  is_destructive: false
  requires_confirmation: false
```

## Componentes

| order | component         | variant   | required | node_id |
|-------|-------------------|-----------|----------|---------|
| 01    | navigation-header | default   | true     | 1:3     |
| 02    | input-text        | default   | true     | 1:21    |
| 03    | input-text        | default   | true     | 1:21    |
| 04    | button-primary    | default   | true     | 1:9     |
| 05    | button-secondary  | default   | true     | 1:11    |

## Reglas aplicadas
- 2 input-text permitidos en formulario-simple (email + contraseña)
- button-primary siempre al final del contenido (positioning rule)
- button-secondary siempre menos prominente que button-primary (hierarchy rule)
- max 1 navigation-header por pantalla

## Notas de aprobación
Pantalla válida para cualquier brief de autenticación: login, acceso, entrar, iniciar sesión. El patrón formulario-simple cubre también registro y recuperación de contraseña con la misma composición base.
