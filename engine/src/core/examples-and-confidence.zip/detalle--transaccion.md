# Example: detalle — transacción

## Metadata
```yaml
screen_id: SCR-004
pattern: detalle
brief: "ver el detalle de una transacción específica"
status: APPROVED
confidence: 0.86
approved_at: 2025-06-01
approved_by: pablo.reguera
```

## Intent
```yaml
intent_type: view
domain: transaccion
constraints:
  has_filters: false
  is_destructive: false
  requires_confirmation: false
```

## Componentes

| order | component         | variant   | required | node_id |
|-------|-------------------|-----------|----------|---------|
| 01    | navigation-header | with-back | true     | 1:3     |
| 02    | card-item         | expanded  | true     | 1:13    |
| 03    | button-primary    | default   | true     | 1:9     |

## Reglas aplicadas
- navigation-header en variante with-back para pantallas de detalle (navigation rule)
- card-item en variante expanded para mostrar información completa
- button-primary para acción principal del detalle (descargar, compartir, repetir)
- max 1 button-primary por pantalla

## Notas de aprobación
Pantalla válida para detalle de cualquier entidad: transacción, fondo, producto, movimiento. La variante with-back del navigation-header es estándar en pantallas secundarias de un flujo de navegación.
