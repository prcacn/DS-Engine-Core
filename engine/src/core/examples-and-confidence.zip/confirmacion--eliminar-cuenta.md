# Example: confirmacion — eliminación de cuenta

## Metadata
```yaml
screen_id: SCR-003
pattern: confirmacion
brief: "confirmar antes de borrar la cuenta del usuario"
status: APPROVED
confidence: 0.85
approved_at: 2025-06-01
approved_by: pablo.reguera
```

## Intent
```yaml
intent_type: confirm
domain: cuenta
constraints:
  has_filters: false
  is_destructive: true
  requires_confirmation: true
```

## Componentes

| order | component            | variant      | required | node_id |
|-------|----------------------|--------------|----------|---------|
| 01    | navigation-header    | default      | true     | 1:3     |
| 02    | modal-bottom-sheet   | destructive  | true     | 1:36    |
| 03    | button-primary       | destructive  | true     | 1:9     |
| 04    | button-secondary     | default      | true     | 1:11    |

## Reglas aplicadas
- modal-bottom-sheet activado por is_destructive: true
- max 1 modal-bottom-sheet abierto simultáneamente (nesting rule)
- button-primary en variante destructive cuando is_destructive: true
- button-secondary siempre disponible como escape (safety rule)

## Notas de aprobación
Pantalla válida para cualquier acción destructiva que requiera confirmación explícita: eliminar cuenta, borrar datos, cancelar suscripción, transferencias irreversibles. La variante destructive del button-primary es obligatoria cuando is_destructive: true.
