# notificaciones

## Descripción
Lista de notificaciones del sistema. Alertas, operaciones completadas, avisos de mercado. Patrón de lectura vertical con agrupación por fecha.

## Cuándo aplicar este pattern
- Centro de notificaciones y alertas del usuario
- Historial de actividad de la cuenta
- Avisos de mercado y operaciones ejecutadas
- Mensajes del sistema y comunicaciones de la plataforma

## Componentes requeridos (en este orden)
1. navigation-header — title: "Notificaciones" o "Alertas"
2. list-header — agrupación temporal ("Hoy", "Ayer")
3. notification-banner — item individual de notificación (3-5 instancias)
4. tab-bar — navegación bottom (usuario autenticado)

## Componentes opcionales
- list-header — segunda agrupación "Esta semana" (repetible hasta 3 veces)
- notification-banner — notificaciones adicionales (repetible hasta 5 total)
- empty-state — si no hay notificaciones pendientes
- filter-bar — para filtrar por tipo de notificación (solo en listados largos)

## Reglas de composición
- navigation-header siempre primero
- tab-bar siempre último
- list-header agrupa los notification-banners por fecha
- notification-banner es el elemento principal y SIEMPRE presente
- empty-state y notification-banner son mutuamente excluyentes en el área de lista
- modal-bottom-sheet PROHIBIDO en listado de notificaciones

## Incompatibilidades
- card-item: no se usa en pantallas de notificaciones (usa notification-banner)
- modal-bottom-sheet: no hay acciones destructivas en listado de notificaciones
