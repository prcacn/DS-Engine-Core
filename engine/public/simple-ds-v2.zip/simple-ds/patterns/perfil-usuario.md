# perfil-usuario

## Descripción
Pantalla de perfil con datos del usuario, métricas personales y acciones disponibles. Contexto financiero: saldo, historial de operaciones, configuración de cuenta.

## Cuándo aplicar este pattern
- Ver datos personales del usuario autenticado
- Gestionar configuración de cuenta
- Acceder a opciones de seguridad y privacidad
- Vista de métricas o resumen personal del usuario

## Componentes requeridos (en este orden)
1. navigation-header — variant: default (es pantalla principal de perfil)
2. list-header — sección "Mis datos" o similar
3. card-item — datos del usuario (email, teléfono, cuenta)
4. tab-bar — navegación bottom (usuario autenticado)

## Componentes opcionales
- list-header — segunda sección "Configuración" (repetible 2 veces)
- card-item — items adicionales de configuración (repetible 2-3 veces)
- badge — estado de cuenta (verificado, activo)
- button-primary — acción principal "Editar perfil"
- button-secondary — acción secundaria "Cerrar sesión"

## Reglas de composición
- navigation-header siempre primero
- tab-bar siempre último (fijo en bottom)
- list-header agrupa secciones de card-items relacionados
- modal-bottom-sheet PROHIBIDO en vista de perfil principal
- empty-state solo si no hay datos de usuario cargados

## Incompatibilidades
- modal-bottom-sheet: la pantalla de perfil no tiene acciones destructivas directas
- filter-bar: el perfil no es un listado filtrable
