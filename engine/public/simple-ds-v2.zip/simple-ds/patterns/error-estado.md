# error-estado

## Descripción
Pantalla de error o estado vacío. Comunica claramente el problema con un mensaje empático y una acción de recuperación clara. Elemento central: empty-state.

## Cuándo aplicar este pattern
- Error de conexión o timeout de red
- Recurso no encontrado (404)
- Operación fallida que impide mostrar contenido
- Lista vacía sin resultados tras búsqueda o error

## Componentes requeridos (en este orden)
1. empty-state — ilustración de error + mensaje + acción de recuperación
2. button-primary — CTA de recuperación ("Reintentar", "Volver al inicio")

## Componentes opcionales
- navigation-header — variant: with-back si hay contexto de navegación anterior
- notification-banner — detalle técnico del error o información adicional
- button-secondary — acción alternativa ("Contactar soporte", "Ir al inicio")

## Reglas de composición
- empty-state es el elemento central y SIEMPRE requerido
- button-primary siempre presente para ofrecer recuperación
- NO card-item en pantallas de error (excluyente con empty-state)
- NO filter-bar
- NO tab-bar (el usuario está en un estado de error, no navegando normalmente)
- modal-bottom-sheet PROHIBIDO

## Incompatibilidades
- card-item: mutuamente excluyente con empty-state
- filter-bar: no hay contenido que filtrar en estado de error
- tab-bar: no se muestra la navegación cuando hay un error crítico de pantalla completa
- modal-bottom-sheet: no hay acciones destructivas en pantallas de error
