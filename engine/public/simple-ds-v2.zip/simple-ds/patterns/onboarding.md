# onboarding

## Descripción
Pantalla de bienvenida con pasos progresivos. Introduce al usuario en la app mostrando valor, progreso y CTA principal. Siempre sin tab-bar (usuario no autenticado).

## Cuándo aplicar este pattern
- Bienvenida a nuevo usuario tras registro
- Introducción a funcionalidades principales de la app
- Flujo de primeros pasos en aplicaciones financieras
- Pantallas de onboarding progresivas con indicadores de paso

## Componentes requeridos (en este orden)
1. navigation-header — variant: default (sin back en primer paso)
2. card-item — 2 o 3 items con highlights de valor de la app
3. button-primary — CTA principal ("Empezar", "Siguiente", "Continuar")

## Componentes opcionales
- notification-banner — indicador de paso/progreso (ej: "Paso 1 de 3")
- list-header — título de sección para agrupar las características
- button-secondary — acción "Saltar" para omitir el onboarding

## Reglas de composición
- navigation-header siempre es el primer elemento
- tab-bar PROHIBIDO en onboarding (usuario no autenticado)
- modal-bottom-sheet PROHIBIDO
- filter-bar PROHIBIDO
- button-primary siempre en la parte inferior de la pantalla
- card-item máximo 3 (highlights de valor, no datos reales)

## Incompatibilidades
- tab-bar: el usuario no está autenticado todavía
- modal-bottom-sheet: no hay acciones destructivas en onboarding
- filter-bar: no hay listados filtrables en esta pantalla
