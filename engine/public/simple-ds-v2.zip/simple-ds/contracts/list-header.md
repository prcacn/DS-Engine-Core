# list-header

## Descripción
Cabecera de sección dentro de una lista o pantalla. Agrupa contenido con un título y una acción opcional ("Ver todo"). Separa visualmente bloques de contenido.

## Propiedades
| Propiedad    | Tipo    | Valores posibles | Valor por defecto |
|--------------|---------|------------------|-------------------|
| title        | string  | Cualquier texto  | "Sección"         |
| show_action  | boolean | true, false      | true              |
| action_label | string  | Cualquier texto  | "Ver todo"        |

## Cuándo usarlo
- Para separar secciones en una pantalla de listado o dashboard
- Antes de un grupo de card-items del mismo tipo
- En pantallas de perfil para agrupar datos relacionados

## Cuándo NO usarlo
- Como cabecera principal de pantalla (usa navigation-header)
- En modales o confirmaciones

## Restricciones
- Puede repetirse 2-3 veces por pantalla
- Siempre precede a un grupo de card-items o notification-banners

## Node ID en Figma
20:797

## Tokens asociados
- background: color-surface-secondary
- title: color-text-primary, weight-bold
- action: color-brand-primary
