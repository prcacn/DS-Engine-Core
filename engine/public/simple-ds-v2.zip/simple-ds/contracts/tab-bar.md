# tab-bar

## Descripción
Barra de navegación inferior. Permite al usuario moverse entre las secciones principales de la app. Siempre visible en pantallas de usuario autenticado.

## Propiedades
| Propiedad    | Tipo   | Valores posibles                        | Valor por defecto |
|--------------|--------|-----------------------------------------|-------------------|
| active_tab   | enum   | inicio, mercado, cartera, perfil        | inicio            |
| show_badges  | boolean| true, false                             | false             |

## Cuándo usarlo
- En todas las pantallas de usuario autenticado como navegación principal
- Siempre en el bottom de la pantalla

## Cuándo NO usarlo
- En pantallas de onboarding o login (usuario no autenticado)
- En modales o bottom sheets
- En pantallas de confirmación destructiva

## Restricciones
- Solo puede aparecer UNA vez por pantalla
- Siempre es el último elemento (y más bajo)

## Node ID en Figma
20:784

## Tokens asociados
- background: color-surface-primary
- active: color-brand-primary
- inactive: color-text-tertiary
