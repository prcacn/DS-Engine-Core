# notification-banner

## Descripción
Banner de notificación inline. Informa al usuario de eventos del sistema, alertas de mercado u operaciones completadas. Aparece en el flujo del contenido.

## Propiedades
| Propiedad | Tipo   | Valores posibles             | Valor por defecto              |
|-----------|--------|------------------------------|-------------------------------|
| title     | string | Cualquier texto              | "Nueva notificación"           |
| subtitle  | string | Cualquier texto              | "Tu operación se ha procesado" |
| type      | enum   | info, success, warning, error| info                          |
| dismissible | boolean | true, false               | false                         |

## Cuándo usarlo
- Para notificaciones del sistema dentro de una lista de notificaciones
- Como feedback de operaciones completadas
- Para alertas contextuales de mercado

## Cuándo NO usarlo
- Para errores críticos de pantalla completa (usa empty-state)
- En modales o confirmaciones

## Restricciones
- Repetible 3-5 veces en patrón notificaciones
- En otros patrones máximo 1

## Node ID en Figma
20:802

## Tokens asociados
- info: color-feedback-info-bg / color-feedback-info
- success: color-feedback-success-bg
- background: color-surface-primary
- border: color-border-subtle
