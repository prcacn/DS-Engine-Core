# badge

## Descripción
Etiqueta de estado compacta. Muestra valores numéricos (variaciones de precio), estados (activo/inactivo) o categorías. Elemento inline que acompaña a otros componentes.

## Propiedades
| Propiedad | Tipo   | Valores posibles                    | Valor por defecto |
|-----------|--------|-------------------------------------|-------------------|
| label     | string | Cualquier texto corto               | "+0.0%"           |
| color     | enum   | positive, negative, neutral, warning| neutral           |

## Cuándo usarlo
- Para mostrar variaciones de precio (positivo/negativo)
- Para indicar estado de una operación o cuenta
- Como indicador visual compacto dentro de card-items o listas

## Cuándo NO usarlo
- Como elemento standalone principal de una pantalla
- Para textos largos (más de 8 caracteres)

## Restricciones
- Elemento auxiliar, siempre acompaña a otro componente
- Máximo 2-3 por pantalla visible

## Node ID en Figma
20:800

## Tokens asociados
- positive: color-feedback-success-bg / color-feedback-success
- negative: color-feedback-error-bg / color-feedback-error
- neutral: color-surface-secondary / color-text-secondary
